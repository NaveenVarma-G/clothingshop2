﻿namespace ClothingStore.DataAccess
{
    public class Cart
    {
        public int Id { get; set; }
        public int count { get; set; }
    }
}
